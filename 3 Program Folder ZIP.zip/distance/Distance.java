package distance;
import java.lang.*;
import java.util.Scanner;
class Point
{
    double x_coord,y_coord;
    Point(Double x,Double y)
    {
        x_coord = x;
        y_coord = y;
    }
    double distancePoint(Point P)
    {
        double distance_val;
        distance_val = Math.sqrt(((x_coord-P.x_coord)*(x_coord-P.x_coord))+((y_coord-P.y_coord)*(y_coord-P.y_coord)));
        return distance_val;
    }
    void showPoint()
    {
        System.out.println("X-Coordinate:"+x_coord+" and Y-Coordinate:"+y_coord);
    }
}
public class Distance
{
    public static void main(String[] args) {
        double x,y;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Object 1,x_coord:");
        x=sc.nextDouble();
        System.out.println("Enter Object 1,y_coord:");
        y=sc.nextDouble();
        Point p1 = new Point(x,y);
        System.out.println("Enter Object 2,x_coord:");
        x=sc.nextDouble();
        System.out.println("Enter Object 2,y_coord:");
        y=sc.nextDouble();
        Point p2 = new Point(x,y);

        System.out.println("The Coordinate of Object 1 is:");
        p1.showPoint();
        System.out.println("The Coordinate of Object 2 is:");
        p2.showPoint();
        System.out.println("Distance:"+p1.distancePoint(p2));
    }
}