import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.Transaction;

public class App {
    public static void main(String[] args) {
        Configuration con = new Configuration();
        con.configure("hibernate.cfg.xml");
        SessionFactory sf = con.buildSessionFactory();
        Session session = sf.openSession();
        Transaction tx = session.beginTransaction();

        products u = new products();

        Scanner ob = new Scanner(System.in);
        int choice;
        int id;
        String p;

        System.out.print("Enter the choice: ");
        choice = ob.nextInt();

        if (choice == 1) {
            System.out.println("Enter the product name : ");
            // id = ob.nextInt();
            p = ob.next();
            System.out.println(p);
            u = session.get(products.class, p);
            // System.out.println("Name: " + u.getProductname());
            System.out.println("Address: " + u.getProductprice());
            System.out.println("Address: " + u.getProductbrand());
        }

        else if (choice == 2) {
            System.out.println("Enter the product name");
            String pname = ob.next();
            System.out.println("Enter the price");
            int pprice = ob.nextInt();
            System.out.println("Enter the brand");
            String pbrand = ob.next();

            u.setProductname(pname);
            u.setProductprice(pprice);
            u.setProductbrand(pbrand);
            session.save(u);
            tx.commit();
        }

        // u.setUid(222);
        // u.setUname("Santa");
        // u.setUemail("abc@gmail.com");
        // session.save(u);
        // tx.commit();

        /*
         * u.setUid(222);
         * u.setUname("Santa");
         * u.setUemail("abc@gmail.com");
         * session.save(u);
         * tx.commit();
         */

    }
}
